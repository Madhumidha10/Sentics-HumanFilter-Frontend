import React from "react";
import './App.css';
import GraphComponent from "./components/GraphComponent";


function App() {
  return (
    <div className="App">
      <GraphComponent />
  
    </div>
  );
}

export default App;

