import React from 'react';
import GraphComponent from './GraphComponent';

const Dashboard = () => {
 
  return (
    <div >
      <GraphComponent  />
 
    </div>
  );
};

export default Dashboard;
